#include<stdio.h>
void counta_z(char str[], int count[])
{
    int i, j, k;
    for (i = 0; str[i] != '\0'; i++);
    for (j = 0; j < 26; j++)
        for (k = 0; k < i; k++)
            if (str[k] == j + 'a' || str[k] == j + 'A')
                count[j] = count[j] + 1;
}
int main()

{
    char str[255];

    int count[26] = { 0 };

    int i;

    gets_s(str);

    counta_z(str, count);

    for (i = 0; i < 26; i++)

        if (count[i])

            printf("%c���ֵĴ���Ϊ:%d\n", i + 'a', count[i]);

}

