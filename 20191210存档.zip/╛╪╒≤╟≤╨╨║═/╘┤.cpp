#include<stdio.h>
int main()
{
	int a[10][10];
	int i, j, k;
	int m, n;
	scanf_s("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf_s("%d", &a[i][j]);
	for (i = 0; i < m; i++)
	{
		k = 0;
		for (j = 0; j < n; j++)
			k = k + a[i][j];
		printf("��%d��Ԫ��֮����%d\n", i, k);
	}
	return 0;
}