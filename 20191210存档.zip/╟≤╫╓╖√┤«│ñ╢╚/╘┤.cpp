#include<stdio.h>
int main()
{
	char a;
	int i = 0;
	while (1)
	{
		a = getchar();
		if (a != '\n')
			i = i + 1;
		else
			break;
	}
	printf("%d", i);
	return 0;
}