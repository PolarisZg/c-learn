#include<stdio.h>
int substring(char* s, char* sub)
{
    int xsub, xs, i, j, k, x1, x2, t;
    for (xsub = 0; sub[xsub] != '\0'; xsub++);
    x1 = xsub;
    for (xs = 0; s[xs] != '\0'; xs++);
    for (i = 0; i < xs ; i++)
    {
        j = 0;
        if (s[i] == sub[j])
        {
            x1 = xsub;
            for (t = 0; t < xsub; t++)
            if (s[i + t] == sub[j + t])
                x1 = x1 - 1;
            if (x1 == 0)
                break;
        }
    }
    if (x1 != 0)
        return -1;
    else
        return i+1;
}
void  main(void)

{

    char s[99], sub[99];

    gets_s(s);

    gets_s(sub);

    if (substring(s, sub) == -1)

        printf("%s�Ӵ�û���ҵ���", sub);

    else

        printf("�Ӵ�%s������%s�е�һ�γ��ֵ�λ����%d", sub, s, substring(s, sub));

}

