#include<stdio.h>
int main()
{
	char a[1000];
	int i, j, k;
	j = k = 0;
	for (i = 0; 1; i++)
	{
		a[i] = getchar();
		if (i>0&&(a[i] == ' ' || a[i] == '\n') && (a[i - 1]>='a'&&a[i-1]<='z'))
			j = j + 1;
		if (i == 4 && a[0] == 's' && a[1] == 't' && a[2] == 'o' && a[3] == 'p' && (a[4] == '\n' || a[4] == ' ') || (i >= 5 && (a[i - 5] == '\n' || a[i - 5] == ' ') && a[i - 4] == 's' && a[i - 3] == 't' && a[i - 2] == 'o' && a[i - 1] == 'p' && (a[i] == '\n' || a[i] == ' ')))
			break;
	}
	printf("%d", j - 1);
	return 0;
}