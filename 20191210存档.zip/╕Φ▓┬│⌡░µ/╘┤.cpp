#include<stdio.h>
int prime(int n)
{
	int i;
	for (i = 2; i <= n; i++)
		if (n % i == 0)
			break;
	if (i == n)
		return 1;
	else
		return 0;
}
int main()
{
	int n, i, j;
	scanf_s("%d", &n);
	for (i = 2; i <= n / 2; i++)
		if (prime(i) && prime(n - i))
			printf("%d=%d+%d\n", n, i, n - i);
	return 0;
}