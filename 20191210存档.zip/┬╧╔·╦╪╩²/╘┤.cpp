#include<stdio.h>
int prime(int k)
{
	int i, j;
	for (i = 2; i <= k; i++)
		if (k % i == 0)
			break;
	if (i == k)
		return 1;
	else
		return 0;
}
int main()
{
	int m, n, i;
	scanf_s("%d%d", &m, &n);
	for (i = m; i <= n - 2; i++)
		if (prime(i) && prime(i + 2))
			printf("[%d,%d]", i, i + 2);
	return 0;
}