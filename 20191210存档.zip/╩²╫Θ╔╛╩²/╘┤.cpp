#include<stdio.h>
int main()
{
	int a[15] = { 1,4,6,9,9,6,19,4,4,8,12,1,9,18,19 };
	int b[15] = { 0 };
	int n = 15;
	int i, j, k;
	scanf_s("%d", &k);
	for (i = 0, j = 0; i < n; i++)
		if (a[i] != k)
		{
			b[j] = a[i];
			j = j + 1;
		}
	for (i = 0; i <= j; i++)
		a[i] = b[i];
	n = j ;
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
	return 0;
}