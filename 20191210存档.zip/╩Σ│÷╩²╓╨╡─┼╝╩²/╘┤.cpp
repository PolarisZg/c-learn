#include<stdio.h>
long compose(long number)
{
    int a[50], i, j, k;
    long n = 0;
    for (i = 0; number != 0; i++)
    {
        a[i] = number % 10;
        number = number / 10;
    }
    for (j = i - 1; j >= 0; j--)
        if (a[j] % 2 == 0)
            n = n * 10 + a[j];
    return n;
}
int main()

{

    long int n;

    scanf_s("%ld", &n);

    printf("%ld\n", compose(n));

    return 0;

}