#include<stdio.h>
int fun(int m, int n, int k)
{
    int xm[100], xn[100], i, j, s;
    for (i = 0; m != 0; i++)
    {
        xm[i] = m % 10;
        m = m / 10;
    }
    for (j = 0; n != 0; j++)
    {
        xn[j] = n % 10;
        n = n / 10;
    }
    if (k < i && k < j && xm[i-k] == xn[j-k])
        return 1;
    else
        return 0;
}
int main()

{
    int m, n, k;

    scanf_s("%d%d%d", &m, &n, &k);

    if (fun(m, n, k))

        printf("YES\n");

    else

        printf("NO\n");

}