#include<stdio.h>
#include<math.h>
int sub(int a, int b)
{
	return a - b;
}
int  add(int a, int b)
{
	return a + b;
}
int main()

{
    int a, b;

    scanf_s("%d%d", &a, &b);

    printf("%d+%d = %d\n", a, b, add(a, b));

    printf("%d-%d = %d\n", a, b, sub(a, b));

}