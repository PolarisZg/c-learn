#include<stdio.h>
int max(int a[])
{
	int max, i, j;
	max = a[0];
	for(i=0;i<6;i++)
		if (max < a[i])
		{
			j = max;
			max = a[i];
			a[i] = j;
		}
	return max;
}
int main()
{
	int a[6] = { 0 };
	int b[6] = { 0 };
	int i, j, k, n;
	scanf_s("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
			scanf_s("%d", &a[j]);
		b[i] = max(a);
	}
	for (i = 0; i < n; i++)
		if (b[0] != b[i])
			break;
	if (i == n)
		printf("YES");
	else
		printf("NO");
	return 0;
}