#include<stdio.h>
int main()
{
	char a[100];
	int b[100];
	int i, j, k;
	for (i = 0; 1; i++)
	{
		a[i] = getchar();
		if (a[i] == '\n')
			break;
	}
	k = i;
	for (i = 0; i < k; i++)
	{
		b[i] = (int)(a[i] - '0');
	}
	for (i = 0; i < k; i++)
		printf("%d", b[i]);
}