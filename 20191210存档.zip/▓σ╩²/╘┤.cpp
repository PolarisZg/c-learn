#include<stdio.h>
int main()
{
	int a[11] = { 1,4,6,9,13,16,19,28,40,100 };
	int i, j, k;
	scanf_s("%d", &a[10]);
	for (i = 0; i < 11; i++)
		for (j = i; j < 11; j++)
			if (a[i] > a[j])
			{
				k = a[i];
				a[i] = a[j];
				a[j] = k;
			}
	for (i = 0; i < 11; i++)
		printf("%d ", a[i]);
	return 0;
}