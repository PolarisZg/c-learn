#include<stdio.h>
#include<math.h>
int main()
{
	int a, b, c;
	float s, p;
	scanf_s("%d%d%d", &a, &b, &c);
	if (a < (b + c) && c < (b + a) && b < (a + c))
	{
		p = (a + b + c) / 2.0;
		s = sqrt(p * (p - a) * (p - b) * (p - c));
		printf("%.2f", s);
	}
	else
		printf("����������");
	return 0;
}