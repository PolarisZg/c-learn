#include<stdio.h>
int main()
{
	int b[10] = { 0 };
	int a[10] = { 0 };
	int i, j, n;
	for (i = 0; 1; i++)
	{
		scanf_s("%d", &b[i]);
		if (b[i] + 1 == 0)
			break;
	}
	for (j = 0; j < i; j++)
	{
		a[j] = b[i - 1 - j];
	}
	n = i;
	for (i = 0; i < n; i++) 
		printf("%d ", a[i]);
	return 0;
}