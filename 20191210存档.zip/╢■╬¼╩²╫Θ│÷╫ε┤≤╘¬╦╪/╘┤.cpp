#include<stdio.h>
void find_max(int a[][4], int n, int b[2])
{
    int c[10][2], i, j, k, t[10];
    for (i = 0; i < n; i++)
    {
        c[i][0]= i;
        c[i][1]= 0;
        t[i] = a[i][0];
        for (j = 0; j < 4; j++)
            if (a[i][0] < a[i][j])
            {
                t[i] = a[i][j];
                c[i][1] = j;
            }
    }
    k = t[0];
    b[0] = c[0][0];
    b[1] = c[0][1];
    for(i=0;i<n;i++)
        if (k < t[i])
        {
            k = t[i];
            b[0] = c[i][0];
            b[i] = c[i][1];
        }
        
}
int main()

{

    int array[10][4], m[2], n, i, j;

    scanf_s("%d", &n);

    for (i = 0; i < n; i++)

        for (j = 0; j < 4; j++)

            scanf_s("%d", &array[i][j]);

    find_max(array, n, m);

    printf("���ֵarray[%d][%d]=%d", m[0], m[1], array[m[0]][m[1]]);

}