#include<stdio.h>
int main()
{
	float a[10];
	int i, j;
	float k;
	for (i = 0; i < 10; i++)
		scanf_s("%f", &a[i]);
	for(i=0;i<10;i++)
		for (j = i; j < 10; j++)
			if (a[i] > a[j])
			{
				k = a[i];
				a[i] = a[j];
				a[j] = k;
			}
	a[1] = (a[1] + a[2] + a[3] + a[4] + a[5] + a[6] + a[7] + a[8]) / 8.00;
	i = (int)(a[1] * 1000) % 10;
	if(i>=5)
		printf("��߷�%.2f\n��ͷ�%.2f\n���÷�%.2f", a[9], a[0],a[1]+0.01);
	else
		printf("��߷�%.2f\n��ͷ�%.2f\n���÷�%.2f", a[9], a[0], a[1]);
	return 0;
}