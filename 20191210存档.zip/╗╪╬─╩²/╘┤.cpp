#include<stdio.h>
int main()
{
	char a[100];
	int i, j, k;
	for (i = 0; 1; i++)
	{
		a[i] = getchar();
		if (a[i] == '\n')
			break;
	}
	k = i - 1;
	j = 0;
	if (k % 2)
		for (i = 0; i <= k / 2; i++)
			if (a[i] != a[k - i])
				j = j + 1;
	if (!(k % 2))
		for (i = 0; i < k / 2; i++)
			if (a[i] != a[k - i])
				j = j + 1;
	if (j == 0)
		printf("���Ǹ�������");
	else
		printf("�ⲻ�ǻ�����");
	return 0;
}