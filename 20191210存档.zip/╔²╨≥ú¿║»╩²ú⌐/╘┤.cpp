#include<stdio.h>
void sort(int a[], int n)
{
    int i, j, k;
    for (i = 0; i < n; i++)
        for(j=i;j<n;j++)
            if (a[i] > a[j])
            {
                k = a[i];
                a[i] = a[j];
                a[j] = k;
            }
}
int main()

{

    int a[10], i, n;

    scanf_s("%d", &n);

    for (i = 0; i < n; i++)

        scanf_s("%d", &a[i]);

    printf("����֮ǰ������:");

    for (i = 0; i < n; i++)

        printf("%d ", a[i]);

    sort(a, n);

    printf("\n����֮�������:");

    for (i = 0; i < n; i++)

        printf("%d ", a[i]);

}