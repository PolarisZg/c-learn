#include<stdio.h>
int main()
{
	int i, j, k, min;
	int a[10];
	for (i = 0; i < 10; i++)
		scanf_s("%d", &a[i]);
	for (i = 0; i < 9; i++)
	{
		for (min = i, j = i + 1; j < 10; j++)
			if (a[min] > a[j])
			{
				k = a[min];
				a[min] = a[j];
				a[j] = k;
			}
	}
	for (i = 0; i < 10; i++)
		printf("%d ", a[i]);
	return 0;
}