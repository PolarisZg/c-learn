#include<stdio.h>
#define M 15
int fun(int* aa, int n, int y)
{
    int b[15], i;
    n = 0;
    for (i = 0; i < 15; i++)
        if (aa[i] != y)
        {
            b[n] = aa[i];
            n = n + 1;
        }
    for (i = 0; i < n; i++)
        aa[i] = b[i];
    return n;
}
int main()

{
    int aa[M] = { 1,2,3,3,2,1,1,2,3,4,5,4,3,2,1 }, n = 15, y, k;

    scanf_s("%d", &y);

    n = fun(aa, n, y);

    for (k = 0; k < n; k++)

        printf("%d ", aa[k]);

    printf("\n");

    return(0);

}

