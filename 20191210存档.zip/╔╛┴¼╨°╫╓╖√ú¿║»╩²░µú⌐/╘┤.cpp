#include<stdio.h>
void del_samechar(char str[])
{
	char a[100], b, c;
	int i, j, k;
	for (i = 0, j = 0; str[i] != '\0'; i++)
	{
		if(i==0&&str[i]!=str[i+1])
		{
			a[j] = str[i];
			j = j + 1;
		}
		else if (i > 0 && str[i] != str[i - 1] && str[i] != str[i + 1])
		{
			a[j] = str[i];
			j = j + 1;
		}
	}
	a[j] = '\0';
	for (i = 0; 1; i++)
	{
		str[i] = a[i];
		if (a[i] == '\0')
			break;
	}
}
int main()

{
	char str[100];

	gets_s(str);

	del_samechar(str);

	puts(str);

}

