#include<stdio.h>
int main()
{
	int n, i, j;
	int C(int a, int b);
	scanf_s("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j <= i; j++)
			printf("%2d", C(i, j));
		printf("\n");
	}
	return 0;
}
int C(int a, int b)
{
	int x, y, i, j;
	if (b == 0 || a == b)
		return 1;
	else
	{
		x = 1;
		y = 1;
		for (i = a; i >= a-b+1; i--)
			x = x * i;
		for (i = 1; i <=b; i++)
			y = y * i;
		x = x / y;
		return x;
	}
}