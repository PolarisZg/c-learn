#include<stdio.h>
char my_toupper(char ch)
{
    if (ch >= 'a' && ch <= 'z')
        ch = ch + 'A' - 'a';
    return ch;
}
int main()

{
    char ch;

    ch = getchar();

    putchar(my_toupper(ch));

}