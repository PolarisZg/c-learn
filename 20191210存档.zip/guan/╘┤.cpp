#include<stdio.h>
#define pi 3.1416
void main()
{
	float h = 0.0, r = 0.0, l = 0.0, s = 0.0, sq = 0.0, v = 0.0, vz = 0.0;
	scanf_s("%f,%f", &r, &h);
	l = 2.0 * pi * r;
	s = pi * r * r;
	sq = 4.0 * pi * r * r;
	v = (4.0 / 3) * pi * r * r * r;
	vz = pi * r * r * h;
	printf("Բ�ܳ�Ϊ:l=%6.2f\n", l);
	printf("Բ���Ϊ:s=%6.2f\n", s);
	printf("Բ������Ϊ:sq=%6.2f\n", sq);
	printf("Բ�����Ϊ:v=%6.2f\n", v);
	printf("Բ�����Ϊ:vz=%6.2f\n", vz);
}
